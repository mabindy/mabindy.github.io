import customtkinter as ctk
from PIL import Image
from pathlib import Path
import subprocess
import os
import requests
import zipfile
import json
current_dir = Path(__file__).parent
installed_versions = os.listdir(f'{current_dir}/PyCraft/Versions')
GITHUB_API_URL = "https://api.github.com/repos/mabindy/PyCraft/releases/latest"
update_window_open = False
def get_local_version(json_file_path):
    try:
        # Read the installed version from the JSON file
        if os.path.exists(json_file_path):
            with open(json_file_path, "r") as json_file:
                version_data = json.load(json_file)
                return version_data.get("local_version", "Unknown")
        else:
            return "Unknown"
    except Exception as e:
        print(f"Error reading version file: {e}")
        return "Unknown"

LOCAL_VERSION = get_local_version(f"{current_dir}/PyCraft/launcher/localversion.json")

def check_for_updates():
    if not update_window_open:
        try:
            LOCAL_VERSION = get_local_version(f"{current_dir}/PyCraft/launcher/localversion.json")
            update_check_button.configure(text="...")
            # Fetch latest tags info from GitHub
            response = requests.get(GITHUB_API_URL)
            response.raise_for_status()
            release_info = response.json()  # This is a list of tags
            # Ensure the response is not empty
            if not release_info:
                print("No releases found on GitHub.")
                return

            # Extract the latest version from the first tag
            latest_version = release_info["tag_name"]  # The "name" key contains the version tag
            release_description = release_info.get("body", "No description provided.")
            assets = release_info.get("assets", [])
            download_url = assets[0]["browser_download_url"]
            # Compare versions
            if latest_version > LOCAL_VERSION:
                show_update(download_url, latest_version, release_description)
                update_message = f"New version available: {latest_version}\nLatest installed version: {LOCAL_VERSION}"
                print(update_message)
            else:
                print("You are already up to date!")
                update_check_button.configure(text="Up to Date!")
                root.after(3000, reset_update_checker)
        except requests.exceptions.RequestException as e:
            print(f"Error checking for updates: {e}")
        except (KeyError, IndexError) as e:
            print(f"Error processing release info: {e}")

def update_version_file(version):
    try:
        version_data = {"local_version": version}

        with open(f"{current_dir}/PyCraft/launcher/localversion.json", "w") as json_file:
            json.dump(version_data, json_file, indent=4)

        print(f"Updated version file")
    except Exception as e:
        print(f"Error updating version file: {e}")

def download_release(download_url, version):
    try:
        print("Downloading new release...")
        update_check_button.configure(text=f"Installing {version}")
        response = requests.get(download_url, stream=True)
        response.raise_for_status()


        output_file = f"{current_dir}/PyCraft/Versions/PyCraft_{version}.zip"
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        with open(output_file, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)
        update_check_button.configure(text=f"Install complete!")
        root.after(3000, reset_update_checker)
        print(f"Download complete! File saved to: {output_file}")
        update_window.destroy()
        reset_update_checker()
        update_version_file(version)
        extract_to = f"{current_dir}/PyCraft/Versions"
        unzip_file(output_file, extract_to)
        installed_versions = os.listdir(f'{current_dir}/PyCraft/Versions')
        version_dropdown.configure(values=sorted([ver for ver in installed_versions]))
    except requests.exceptions.RequestException as e:
        print(f"Error downloading release: {e}")

def unzip_file(zip_path, extract_to):
    try:
        os.makedirs(extract_to, exist_ok=True)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)

        os.remove(zip_path)
    except zipfile.BadZipFile as e:
        print("Bad Zip")
    except Exception as e:
        print(f"Error unzipping file: {e}")

def reset_update_checker():
    update_check_button.configure(text=f"Check For Updates")
def launch_game():
    try:
        env = os.environ.copy()
        env["PYCRAFT_USERNAME"] = username
        subprocess.Popen(['python', f'{current_dir}/PyCraft/Versions/{version_dropdown.get()}/pycraft.py'], env=env)
        root.quit()
    except Exception as e:
        ctk.CTkMessagebox(title="Error", message=f"Could not launch PyCraft: {e}")

def show_update(url, newver, patchnotes):
    global update_window, update_window_open
    update_window_open = True
    update_window = ctk.CTkToplevel()
    update_window.title("New Update Available")
    update_window.geometry("300x200")
    update_window.attributes("-topmost", True)
    update_window.resizable(False, False)
    update_window.protocol("WM_DELETE_WINDOW", lambda: close_update_menu())

    newupdatetext = ctk.CTkLabel(update_window, text="A New Version Of PyCraft Is Available!")
    newupdatetext.pack(pady=10)

    updateversion = ctk.CTkLabel(update_window, font=ctk.CTkFont(size=18), text=newver)
    updateversion.pack(pady=5)

    patch_notes_button = ctk.CTkButton(update_window, text="Patch Notes", width=70, command=lambda: show_patch_notes(patchnotes, newver))
    patch_notes_button.pack(pady=5)

    install_button = ctk.CTkButton(update_window, text="Install", fg_color="#24ab26", width=70, command=lambda: download_release(url, newver))
    install_button.pack(side="right", padx=40, pady=10)

    cancel_button = ctk.CTkButton(update_window, text="Cancel", fg_color="#e01414", width=75, command=lambda: close_update_menu())
    cancel_button.pack(side="left", padx=40, pady=10)

def close_update_menu():
    global update_window_open, update_window
    update_window.destroy()
    reset_update_checker()
    update_window_open = False

def show_patch_notes(patchnotes, ver):
    patch_notes_window = ctk.CTkToplevel()
    patch_notes_window.title(f"{ver} Patch Notes")
    patch_notes_window.geometry("700x500")
    patch_notes_window.attributes("-topmost", True)
    versiontext = ctk.CTkLabel(patch_notes_window, font=ctk.CTkFont(size=18), text=f"PyCraft {ver}\n______")
    versiontext.pack(pady=10)
    notes = ctk.CTkLabel(patch_notes_window, text=patchnotes)
    notes.pack(pady=10)
def save_settings(resolution):
    print(f"Resolution set to: {resolution}")

def open_versions_folder():
    try:
        if not os.path.exists(f'{current_dir}/PyCraft/Versions'):
            print("Versions folder does not exist.")
            return

        os.startfile(f'{current_dir}/PyCraft/Versions')
    except Exception as e:
        print(f"Error opening versions folder: {e}")

# Main launcher window
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue") 

root = ctk.CTk()
root.title("PyCraft Launcher")
root.geometry("800x500")
root.minsize(800,500)
root.maxsize(800,500)

button_width = 170
button_height = 30
target_size = 160
default_size = button_width
animation_speed = 1
username = None
def get_user_details():
    with open(f"{current_dir}/PyCraft/launcher/userdetails.json", "r") as json_file:
        userdetailsdata = json.load(json_file)
        return userdetailsdata.get("username", "Unknown")


def build_username_page():
    global entry, username_label, confirm_button
    label_image = ctk.CTkImage(Image.open(f"{current_dir}/PyCraft/launcher/usernamelabel.png"), size=(700,200))
    username_label = ctk.CTkLabel(root, image=label_image, text="")
    username_label.pack(pady=0)
    entry = ctk.CTkEntry(root, placeholder_text="Username", width=300, height=40, justify="center")
    entry.pack(pady=30)
    confirm_button = ctk.CTkButton(root, text="Confirm", font=ctk.CTkFont(size=18), command=create_username, border_width=3, border_color="black", fg_color="#24ab26", hover_color="#1b801c", width=200, height=50)
    confirm_button.pack(pady=50)
    pass

def create_username():
    global username
    data = {"username": entry.get()}
    with open(f"{current_dir}/PyCraft/launcher/userdetails.json", "w") as json_file:
        json.dump(data, json_file, indent=4)
    entry.destroy()
    username_label.destroy()
    confirm_button.destroy()
    username = get_user_details()
    build_main_page()

logout_button = None

def log_out():
    global username, user_dropdown
    if os.path.exists(f"{current_dir}/PyCraft/launcher/userdetails.json"):
        os.remove(f"{current_dir}/PyCraft/launcher/userdetails.json")
    username = None
    for widget in root.winfo_children():
        widget.destroy()
    build_username_page()

def toggle_user_menu():
    global logout_button
    if logout_button:
        logout_button.destroy()
        logout_button = None
        return
    logout_icon = ctk.CTkImage(Image.open(f"{current_dir}/PyCraft/launcher/logout.png"), size=(20,20))
    logout_button = ctk.CTkButton(root, image=logout_icon,text="", command=log_out, width=15, fg_color="#e01414", hover_color="#b01010")
    logout_button.place(x=10,y=45)

def build_main_page():
    global version_dropdown_values, version_dropdown, play_button, settings_button, file_button, update_check_button
    game_image = ctk.CTkImage(Image.open(f"{current_dir}/PyCraft/launcher/launcherimage.png"), size=(600,350))
    bg_image = ctk.CTkLabel(root, image=game_image, text="")
    bg_image.place(relx=0.125, rely=0.15)
    version_dropdown_values = sorted([ver for ver in installed_versions], reverse=True)
    version_dropdown = ctk.CTkOptionMenu(root, values=version_dropdown_values)
    version_dropdown.place(x=50, y=450)
    if version_dropdown_values == []:
        version_dropdown.set("No Installed Versions")
    play_icon = ctk.CTkImage(Image.open(f"{current_dir}/PyCraft/launcher/playbutton.png"), size=(30,30))
    play_button = ctk.CTkButton(root, text="", image=play_icon, font=ctk.CTkFont(size=18), width=button_width, height=button_height, command=launch_game, fg_color="#24ab26", hover_color="#1b801c", border_width=3, border_color="#474747")
    play_button.place(x=395, y=463, anchor="center")
    launcherlabel = ctk.CTkLabel(root, font=ctk.CTkFont(size=24), text="PyCraft Launcher")
    launcherlabel.pack(pady=10)
    user_icon = ctk.CTkImage(Image.open(f"{current_dir}/PyCraft/launcher/usericon.png"), size=(20,20))
    file_icon = ctk.CTkImage(Image.open(f"{current_dir}/PyCraft/launcher/fileicon.png"), size=(20,20))
    user_button = ctk.CTkButton(root, text=username, image=user_icon, font=ctk.CTkFont(size=18), width=20, height=25, fg_color="#6b6b6b", hover_color="#4d4d4d", command=toggle_user_menu)
    user_button.place(x=10, y=10)
    file_button = ctk.CTkButton(root, text="", image=file_icon, font=ctk.CTkFont(size=18), width=15, height=25, command=open_versions_folder, fg_color="#6b6b6b", hover_color="#4d4d4d")
    file_button.place(x=10, y=450)
    update_check_button = ctk.CTkButton(root, text="Check For Updates",  font=ctk.CTkFont(size=18), width=170, command=check_for_updates, fg_color="#6b6b6b", hover_color="#4d4d4d")
    update_check_button.place(x=625, y=10)

    quit_button = ctk.CTkButton(root, text="Quit", font=ctk.CTkFont(size=18), command=root.quit)
    quit_button.place(x=600, y=450)

    version_label = ctk.CTkLabel(root, text="Created by Mabindy", font=ctk.CTkFont(size=12), height=10)
    version_label.place(x=340, y=485)

if os.path.exists(f"{current_dir}/PyCraft/launcher/userdetails.json"):
    username = get_user_details()
    if username == "Unknown":
        build_username_page()
    else:
        build_main_page()
        check_for_updates()
else:
    build_username_page()
root.mainloop()
